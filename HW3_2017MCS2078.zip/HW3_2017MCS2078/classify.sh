#!/bin/sh
python3 part2_ri.py $1 $2 $3 $4
