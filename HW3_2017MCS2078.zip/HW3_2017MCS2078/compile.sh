#!/bin/sh
make -B