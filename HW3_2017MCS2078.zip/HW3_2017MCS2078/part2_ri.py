import numpy as np
import sys, os, math
#from tqdm import tqdm

m = {13 :'Br',31:'Sn' ,18:'Mg' , 6:'F',53:'Yb' ,36:'Ti' ,42:'Tb' ,56:'Nb' ,17:'Cu' , 2:'C',44:'W' ,27:'Al' ,32:'Sb' ,30:'Zr' ,43:'Te' ,21:'Fe' ,49:'Os' , 1:'O',55:'Tl' ,14:'I' , 5:'P',22:'Co' ,50:'Nd' , 4:'Cl',35:'Ca' ,52:'Gd' ,24:'Ir' ,45:'Cs' ,37:'Ho' , 7:'Rh', 3:'N',39:'Cr' ,15:'Se' ,46:'Mo' ,47:'Re' ,48:'Cd' , 8:'Li',28:'Ni' , 0:'S',51:'Sm' ,12:'B' ,34:'Hg' ,41:'Au' ,57:'Ac' ,10:'As' ,11:'Na' ,29:'V' ,26:'Mn' ,25:'Ru' ,33:'Bi' ,23:'U' ,19:'Zn' , 9:'Ga',20:'Si' ,16:'K' ,40:'Ag' ,38:'Ge' ,54:'Er' }
out_label={} #Key: train id, value: label
freq=dict() #key: subgraph id, value:(num_edges, list of graph index of train data)
count_test=0
gid=dict() #key: graph_id value: count of subgraphs present in this key
feature =[] #list of sub graph ids selected as features
delta=10
train_vector=[] #column i represents feature vector of graph i 
test_vector=[]
graph_map={} #key:graph id, value: graph index
ri_subg_string_map={} #key: subgraph_id, value: string of subgraph in ri format
positive=0
negative=0
freq_cnt = {}
def mol_label(active_train, inactive_train):
	#print(active_train, inactive_train)
	global out_label, positive, negative
	f=open(active_train, "r")
	for line in f:
		if(int(line) in graph_map):
			out_label[graph_map[int(line)]]=1
			positive+=1
	f.close()
	f=open(inactive_train, "r")
	for line in f:
		if(int(line) in graph_map):
			out_label[graph_map[int(line)]]=-1
			negative+=1
	f.close()

def read_input_data(input_file, formatted_file):
	global gid, graph_map
	f=open(input_file, "r")
	f1=open(formatted_file, "w")

	#parsing the input file to convert into format for gspan and storing graph ids in dictionary gid with value 0
	molecule=dict()
	count=0
	ind=0
	for line in f:
		graph_id=line[1:]
		graph_map[int(graph_id)]=ind
		ind+=1
		gid[int(graph_id)]=0
		f1.write("t # "+graph_id)
		line=f.readline()
		num_nodes=line
		for i in range(int(num_nodes)):
			line=f.readline()
			if line not in molecule:
				molecule[line]=count
				count+=1
			f1.write("v "+str(i)+" "+str(molecule[line])+"\n")
		line=f.readline()
		num_edges=line
		for i in range(int(num_edges)):
			line=f.readline()
			f1.write("e "+line)
	f.close()
	f1.close()	

def parse_test_data(test_file):
	global count_test
	f=open(test_file, "r")
	count=0
	for line in f:
		line=f.readline()
		num_nodes=line
		for i in range(int(num_nodes)):
			line=f.readline()
		line=f.readline()
		for i in range(int(line)):
			line=f.readline()
		count_test+=1
	f.close()	

def parse_gspan_output(output_file):
	global freq, ri_subg_string_map,freq_cnt
	f=open(output_file, "r")
	for line in f:
		subg_ri=""
		t_line=line.split(' ')
		subg_ri+=("#"+t_line[2]+"\n")
		num_nodes=0
		vert=""
		graph_list=[]
		line=f.readline()
		while(line[0]=='v'):
			num_nodes+=1
			v_line=line.split(' ')
			vert+=m[int(v_line[2])]+"\n"
			line=f.readline()
		subg_ri+=(str(num_nodes)+"\n")
		if(num_nodes>0):
			subg_ri+=(vert)
		num_edges=0
		ed=""
		while(line[0]=='e'):
			num_edges+=1
			e_line=line.split(' ')
			ed+=(e_line[1]+" "+e_line[2]+" "+e_line[3])
			line=f.readline()
		subg_ri+=(str(num_edges)+"\n")
		if(num_edges>0):
			subg_ri+=(ed)

		if(line[0]=='x'):
			line.rstrip('\n')
			x_line=line.split(' ')
			for i in range(1, len(x_line)):
				if(x_line[i]=='\n'):
					continue
				graph_list.append(int(x_line[i]))
		line=f.readline()
		if(num_nodes==1 and num_edges==0):
			continue
		freq[int(t_line[2])]=(num_edges, graph_list)
		freq_cnt[int(t_line[2])]=num_nodes
		ri_subg_string_map[int(t_line[2])]=subg_ri
	f.close()
	#print("Number of total subgraphs", len(freq))


def non_zero():
	cnt = 0
	for g in gid:
		if(gid[g]!=0):
			cnt+=1
	return cnt

def feature_selection1():
	global feature
	log_score={}
	maxm=0
	for g in freq:
		c1=0
		c2=0
		num_e,l_g=freq[g]
		for l in l_g:
			if(l not in out_label):
				continue
			if(out_label[l]==1):
				c1+=1
			else:
				c2+=1
		r1=(c1+1)/(positive+1)
		r2=(c2+1)/(negative+1)
		score=abs(np.log(r1/r2)/(num_e+1))
		log_score[g]=score
		if(score>maxm):
			maxm=score
	for g, x in log_score.items():
		if(x>=maxm*0.15):
			feature.append(g)
	#print("features: ", len(feature))

def feature_selection1_3():
	global feature
	log_score={}
	maxm=0
	for g in freq:
		c1=0
		c2=0
		num_e,l_g=freq[g]
		for l in l_g:
			if(l not in out_label):
				continue
			if(out_label[l]==1):
				c1+=1
			else:
				c2+=1
		r1=(c1+1)/(positive+1)
		r2=(c2+1)/(negative+1)
		score= (2*(c1)*(math.log(r1/r2)))+(2*(positive-c1)*math.log(((positive-c1+1)/positive+1)/((negative-c2+1)/negative+1)))
		log_score[g]=score
		if(score>maxm):
			maxm=score
	for g, x in log_score.items():
		if(x>=maxm*0.05):
			feature.append(g)

def feature_selection1_2():
	global feature
	log_score={}
	maxm=0
	for g in freq:
		c1=0
		c2=0
		num_e,l_g=freq[g]
		for l in l_g:
			if(l not in out_label):
				continue
			if(out_label[l]==1):
				c1+=1
			else:
				c2+=1
		r1=(c1+1)/(positive+1)
		r2=(c2+1)/(negative+1)
		score=np.log(r1/r2)/(num_e+1);
		log_score[g]=score
		if(score>maxm):
			maxm=score
	ii = 0
	ls=sorted(log_score.items(), key=lambda k: k[1], reverse=True)
	for g,d in ls:
		#print(g)
		#if(len(feature)>200):
		#	break
		ii +=1
		print("graph no. ",ii,end =' ')
		if(len(feature)==0):
			feature.append(g)
			continue
		flag = 0
		for g1 in feature:
			if(freq_cnt[g]>=freq_cnt[g1]):
				maxm = g
				minm = g1
			else:
				maxm = g1
				minm = g
			if(freq_cnt[g]>=freq_cnt[g1]):
				f11=open("ri_input1.txt", "w")
				f11.write(ri_subg_string_map[minm])
				f11.close()
				f11=open("ri_input2.txt", "w")
				f11.write(ri_subg_string_map[maxm])
				f11.close()
				os.system("./ri36 mono geu "+"ri_input2.txt"+" ri_input1.txt > ri_output.txt")
				g_list=[]
				f11=open("ri_output.txt", "r")
				for line in f11:
					g_list.append(int(line))
				f11.close()
				if(len(g_list)>0):
					if(freq_cnt[g]>=5 and freq_cnt[g]<=10):
						flag = 1
						feature.remove(g1)
				else:
					flag = 1
			else:
				f11=open("ri_input1.txt", "w")
				f11.write(ri_subg_string_map[g])
				f11.close()
				f11=open("ri_input2.txt", "w")
				f11.write(ri_subg_string_map[g1])
				f11.close()
				os.system("./ri36 mono geu "+"ri_input2.txt"+" ri_input1.txt > ri_output.txt")
				g_list=[]
				f11=open("ri_output.txt", "r")
				for line in f11:
					g_list.append(int(line))
				f11.close()
				if(len(g_list)>0):
					if(freq_cnt[g1]>=5 and freq_cnt[g1]<=10):
						pass
					else:
						flag = 1
						feature.remove(g1)
				else:
					flag = 1
		if flag==1:
			flag =0
			feature.append(g)

		# if(x>=maxm*0.2):
		# 	feature.append(g)
		print("features: ", len(feature))

def feature_selection_cork_partial():
	global feature
	log_score={}
	maxm=0
	for g in freq:
		c1=0
		c2=0
		num_e,l_g=freq[g]
		for l in l_g:
			if(l not in out_label):
				continue
			if(out_label[l]==1):
				c1+=1
			else:
				c2+=1
		score=-(c1*c2+(positive-c1)*(negative-c2))
		log_score[g]=score
		if(score>maxm):
			maxm=score
	ls=sorted(log_score.items(), key=lambda k: k[1], reverse=True)
	
	cn=0
	for g, x in log_score.items():
		if(cn<int(0.3*len(log_score))):
			feature.append(g)
			cn+=1
	#print("features: ", len(feature))

def feature_selection():
	global feature, gid, delta, sorted_frequent
	score={}
	for g in freq:
		c1=0
		c2=0
		num_e , lg = freq[g]
		for x_line in lg:
			if(int(x_line) not in out_label):
				continue
			if(out_label[int(x_line)]==1):
				c1+=1
			else:
				c2+=1
		score[int(g)]=c1/(c1+c2)
	sorted_frequent=sorted(score.items(), key=lambda k: k[1], reverse=True)
	for g, sc in sorted_frequent:
		feature.append(g)
		num_e, l_g=freq[g]
		for x_line in l_g:
			if(int(x_line) in gid):
				gid[int(x_line)]+=1
				if(gid[int(x_line)]>=delta):
					gid.pop(int(x_line), 'None')
		if(len(gid)==0 or len(feature)>1500																																																																																																																																																																																																																																																																																																																																																							):
			break

def feature_selection_delta():
	global feature
	log_score={}
	maxm=0
	for g in freq:
		c1=0
		c2=0
		num_e,l_g=freq[g]
		for l in l_g:
			if(l not in out_label):
				continue
			if(out_label[l]==1):
				c1+=1
			else:
				c2+=1
		log_score[g]=max(c1-c2,c2-c1)
		if(log_score[g]>maxm):
			maxm=log_score[g]
	for g, x in log_score.items():
		if(x>=maxm*0.1):
			feature.append(g)

def graph_isomorphism(output_test_file, test_file): #on test data
	global test_vector
	#print(len(feature),len(gid))
	ctt = 0
	a=0
	for sub_g in feature:#tqdm(feature, total=len(feature)):
		l=[0]*count_test
		ctt=0
		f1=open("ri_input.txt", "w")
		f1.write(ri_subg_string_map[sub_g])
		f1.close()
		os.system("./ri36 mono geu "+test_file+" ri_input.txt > ri_output.txt")
		g_list=[]
		f1=open("ri_output.txt", "r")
		for line in f1:
			g_list.append(int(line))
		f1.close()
		for x in g_list:
			l[x]=1
		test_vector.append(l)
		#print("g_list: ", len(g_list), "actual: ", len(freq[sub_g][1]))
	test_vector=np.array(test_vector)
	f=open(output_test_file, "w")
	for c in range(test_vector.shape[1]):
	    for r in range(len(test_vector[:,c])):
	        f.write(str(r)+":"+str(test_vector[r,c])+" ")
	    f.write("\n")
	f.close()

def make_train_vector(output_train_file):
	global train_vector, freq
	cnt=0
	for i in feature:
		l=[0]*len(graph_map)
		ne, l_g=freq[i]
		for x in l_g:
			l[x]=1
		train_vector.append(l)
	train_vector=np.array(train_vector)
	#print(train_vector.shape)
	f=open(output_train_file, "w")
	for c in range(train_vector.shape[1]):
	    if(c in out_label):
	        f.write(str(out_label[c]))
	        for r in range(len(train_vector[:,c])):
	            f.write(" "+str(r)+":"+str(train_vector[r,c]))
	        f.write("\n")
	f.close()

train_file=sys.argv[1]#"dataset.txt"
formatted_file="gspan_input"
gspan_op_file=formatted_file+".fp"
test_file=sys.argv[4]#"dataset.txt"
train_op_file="train.txt"
test_op_file="test.txt"
active_label=sys.argv[2]#"ca.txt"
inactive_label=sys.argv[3]#"ci.txt"


read_input_data(train_file, formatted_file)
mol_label(active_label, inactive_label)
os.system("./gSpan-64 -f "+formatted_file+" -s 0.05 -o -i")
parse_gspan_output(gspan_op_file)
sorted_frequent=sorted(freq, key=lambda k: len(freq[k]), reverse=True)
feature_selection1_3() #on train data
#print("feature_selection: ", len(feature))
make_train_vector(train_op_file)
parse_test_data(test_file)
graph_isomorphism(test_op_file, test_file)
