f=open("dataset.txt", "r")
f1=open("gspan_input", "w")

molecule=dict()
count=0
for line in f:
	#line=f.readline()
	#print(line)
	graph_id=line[1:]
	f1.write("t # "+graph_id)
	#print(graph_id)
	line=f.readline()
	num_nodes=line
	#print(num_nodes)
	for i in range(int(num_nodes)):
		line=f.readline()
		if line not in molecule:
			molecule[line]=count
			count+=1
		f1.write("v "+str(i)+" "+str(molecule[line])+"\n")
	line=f.readline()
	num_edges=line
	for i in range(int(num_edges)):
		line=f.readline()
		f1.write("e "+line)
print(molecule, len(molecule))
f.close()
f1.close()	
