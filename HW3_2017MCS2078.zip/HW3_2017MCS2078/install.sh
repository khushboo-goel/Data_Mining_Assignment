#!/bin/sh
git clone https://github.com/khushboo-goel/Data_Mining_Assignment.git

#Our code will work on a 64-bit machine