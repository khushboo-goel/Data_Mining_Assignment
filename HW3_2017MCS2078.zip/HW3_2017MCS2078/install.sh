#!/bin/sh
git clone https://github.com/khushboo-goel/Data_Mining_Assignment.git

#Our code will work on a 64-bit machine
#Make sure: Right click on gSpan-64 executable, Properties->Permissions->Allow executing file as program should be checked
#Make sure: Right click on ri3 executable, Properties->Permissions->Allow executing file as program should be checked
