2017MCS2078:Sruti Goyal
2017MCS2082:Jyoti
2017MCS2084:Khushboo Goel

Tool used:
1. GSPAN tool: To find all the frequent subgraphs present in the dataset
2. RI library: To find if a given graph is subgraph isomorphic to another graph