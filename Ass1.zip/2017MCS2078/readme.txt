COL 761- Data Mining

Assignment 1: Implementation of Apriori and FP Tree Frequent Pattern Mining Algorithms

Submitted to: Prof. Sayan Ranu

Submitted by: Sruti Goyal   2017MCS2078
              Jyoti         2017MCS2082
              Khushboo Goel 2017MCS2084

The submitted folder contains following files:
1. compile.sh: contains command to compile apriori_final.cpp and fptree_final.cpp
2. 2017MCS2078.sh : contains the command to run apriori_final.cpp, fptree_final.cpp and plot.py
3. apriori_final.cpp: contains the implementation of Apriori Algorithm
4. fptree_final.cpp: contains the implementation of FP Tree Algorithm.
5. plot.py: for plotting the graph using matplotlib library on 1, 5, 10, 25, 50 and 90% support threshold


Observation for Q.2 Part B

Note: We have sorted the transactions based on frequency of items in FP Tree Algorithm.

1. Both algorithms show a decrease in running time with increase in the support threshold because with higher support threshold, more itemsets will be filtered out from being the frequent itemsets. This happens because there are lesser candidate itemsets in Apriori and lesser items to form conditional tree in FP Tree. Lesser itemsets means lesser file reads, cross products(or joins) and subset checking are required in Apriori. Also lesser itemsets means lesser number of trees and smaller heights for each conditional FP tree, resulting in lesser time for tree traversal in FP tree. 

2. Apriori Algorithm is slower as compared to FP Tree because Apriori Algorithm tends to form candidate itemsets in a breadth-wise fashion and each iteration requires a read of transaction file to calculate the frequency of candidate itemsets. FP Tree on the other hand, reads the file once, does not generate candidate itemsets and instead forms a tree to find frequent itemsets. Also, traversals in conditional FP Tree are lesser expensive than reading data from file.