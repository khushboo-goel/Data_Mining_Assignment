import matplotlib.pyplot as mpl
import sys

def plot(x,y, y1):
    mpl.plot(x,y,'-', label = "Apriori ")
    mpl.plot(x,y1,'-', label = "FP Tree")
    mpl.xlabel("Support Threshold (%)")
    mpl.ylabel("Running Time (in sec)")
    mpl.title("Variation of Running Time with Support Threshold")
    mpl.legend(loc=1)
    mpl.savefig("2017MCS2078_plot.png")
    mpl.show()

#print(type(sys.argv[1]))
y=[]
y1=[]
s=sys.argv[1].split(' ')
s1=sys.argv[2].split(' ')
for i in range(1,len(s)):
    y.append(float(s[i])/1000000000)
    y1.append(float(s1[i])/1000000000)
x=[1, 5, 10, 25, 50, 90]
plot(x, y, y1)
