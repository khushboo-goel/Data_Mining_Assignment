#!/bin/sh
if [ "$3" = "-apriori" ]
then
	./ap $1 $2 $4
elif [ "$3" = "-fptree" ] 
then
	./fp $1 $2 $4
elif [ "$2" = '-plot' ]
then
	run_ap=""
    run_fp=""
    for i in 1 5 10 25 50 90
    do
        ap_it=`date +%s%N`
        ./ap $1 $i 'op_ap'
        ap_ft=`date +%s%N`
        ap_rt=$((ap_ft-ap_it))
        run_ap="$run_ap $ap_rt"
        #run_ap+=("$ap_rt")
        fp_it=`date +%s%N`
        ./fp $1 $i 'op_fp'
        fp_ft=`date +%s%N`
        fp_rt=$((fp_ft-fp_it))
        run_fp="$run_fp $fp_rt"
        #run_fp+=("$fp_rt")
    done
    python plot.py "$run_ap" "$run_fp"
else
	echo Invalid Option
fi


