#include<iostream>
#include <fstream>
#include <sstream>
#include<map>
#include<vector>
#include<algorithm>
#include<ctime>
using namespace std;
map<vector<string>, int> c1, f1;
ofstream ofile;
void write_data(map<vector<string>, int> c)
{ 
	for(map<vector<string>, int>::iterator i=c.begin();i!=c.end();i++)
	{	
		ofile<<i->first[0];
		for(int j=1;j<i->first.size();j++)
		{
			ofile<<" "<<i->first[j];
		}
		ofile<<endl;
	}
	return;
}
int read_data(fstream &f, float thresh)
{
	string word, line, t=""; 
	int count=0; 
	vector<string> v;
	/*while(getline(file, line))
	{
		count++;
		stringstream ss(line);
        while (getline(ss, word, ' '))
        {
            v.clear();
		    v.push_back(word);
		    if(c1.find(v)==c1.end())
			    c1[v]=1;
		    else
			    c1[v]+=1;
	    }
	}*/
	char c;
	int ct=0;
    while(f>>noskipws>>c)
    {
        //cout<<c;
        
        if(c==' ')
        {
            v.push_back(t);
            if(c1.find(v)==c1.end())
		        c1[v]=1;
	        else
		        c1[v]+=1;
		    v.clear();   
            t="";
        }
        else if(c=='\n')
        {
            if(t!="")
            {   //cout<<"here";
                v.push_back(t);
                if(c1.find(v)==c1.end())
			        c1[v]=1;
		        else
			        c1[v]+=1;
			}
            v.clear();
            t="";
            ct++;
        }    
        else
            t+=c;
            
    }
	for(map<vector<string>, int>::iterator i=c1.begin();i!=c1.end();i++)
	{
	    //cout<<i->first.size()<<" "<<i->second<<" "<<thresh<<endl;
		if((i->second/float(ct))*100>=thresh)
		{
		
    //cout<<"c1 size: ";
			f1[i->first]=i->second;
			//cout<<i->first[0]<<" "<<i->second<<endl;		
		}
	}
	write_data(f1);
	return ct;
}
void candidate_generation(map<vector<string>, int> f1)
{
	vector<string> iv, jv, v, v1;
	int f, f2;
	c1.clear();
	for(map<vector<string>, int>::iterator i=f1.begin(); i!=f1.end();i++)
	{
		iv.clear();
		iv=i->first;
		map<vector<string>, int>::iterator j=i;
		j++;
		for(; j!=f1.end();j++)
		{
			jv.clear();
			jv=j->first;
		    f=0;
			if(iv[iv.size()-1]<jv[jv.size()-1])
			{
				for(int k=0;k<iv.size()-1;k++)
				{
					if(iv[k]!=jv[k])
					{
						f=1;
						break;
					}
				}
				if(f!=1)
				{
					v=iv;
					v.push_back(jv[jv.size()-1]);
					f2=1;
					for(int l=0;l<iv.size();l++)
					{
						v1=v;
						v1.erase(v1.begin()+l);
						if(f1.find(v1)==f1.end())
						{
							f2=0;			
							break;			
						}
						//else break;
					}
					if(f2==1)
					{
					    c1[v]=0;
					}
				}
			}
		}
	}
}
void read(fstream &f, float thresh, int count)
{
	string line, t=""; 
    vector<string> v, iv;
    string item;
    f1.clear();
    int cnt=0, flag, k, j;
    char c;
    while(f>>noskipws>>c)
    {
        //cout<<c;
        
        if(c==' ')
        {
            v.push_back(t);   
            t="";
        }
        else if(c=='\n')
        {
            if(t!="")
                v.push_back(t);
            sort(v.begin(), v.end()); 
            for(map<vector<string>, int>::iterator i=c1.begin(); i!=c1.end();i++)
            {
			    k=0;
                flag=0;
                //iv.clear();
                //iv=i->first;
                for(j=0;j<i->first.size() && k<v.size();)//v is the current transaction (iterator: k), i->first is the itemset(iterator: j)
                {
                    while(i->first[j]>v[k])
                    {
                        k++;
                        if(k==v.size())
                        {
                            flag=1;
                            break;
                        }
                    }
                    if(flag==1)
                        break;
                    if(i->first[j]==v[k])
                    {
                        j++; k++;
                    }
                    else if(i->first[j]<v[k])
                    {
                        flag=1;
                        break;
                    }
                    
                }
		            
                if(flag!=1 &&j==i->first.size())
                    i->second+=1;
            }
            v.clear();
            t="";
        }    
        else
            t+=c;
            
    }
    /*while(getline(file, line))
	{
	    stringstream ss(line);
        v.clear();
        
        while (getline(ss, item, ' '))
        {
           v.push_back(item);
        }//read_word(v, line, item);
        sort(v.begin(), v.end()); 
        for(map<vector<string>, int>::iterator i=c1.begin(); i!=c1.end();i++)
        {
			k=0;
            flag=0;
            iv.clear();
            iv=i->first;
            for(j=0;j<iv.size() && k<v.size();)//v is the current transaction (iterator: k), i->first is the itemset(iterator: j)
            {
                while(iv[j]>v[k])
                {
                    k++;
                    if(k==v.size())
                    {
                        flag=1;
                        break;
                    }
                }
                if(flag==1)
                    break;
                if(iv[j]==v[k])
                {
                    j++; k++;
                }
                else if(iv[j]<v[k])
                {
                    flag=1;
                    break;
                }
                
            }
		        
            if(flag!=1 &&j==iv.size())
                i->second+=1;
        }
	}*/
	for(map<vector<string>, int>::iterator i=c1.begin(); i!=c1.end();i++)
    {
        //cout<<i->first.size()<<" "<<i->second<<" "<<count<<endl;
		if((i->second/float(count))*100>=thresh)
	    {
	        f1[i->first]=i->second;
		    //cout<<i->first.size()<<" "<<i->second<<" "<<count<<endl;		
        }
    }
	write_data(f1);
}
int main(int argc, char** argv)
{
    //const clock_t begin_time = clock();
	string fname=argv[1];
    fstream file;
	file.open(fname.c_str());
	int threshold = 1;
	stringstream ss(argv[2]);
	ss>>threshold;
    string op_file=argv[3];
    op_file+=".txt";
	ofile.open(op_file.c_str());
	
	int count = read_data(file, threshold);
	for(int i=2;;i++)
	{
		candidate_generation(f1);
	    file.clear();
        file.seekg(0, ios::beg);
		read(file, threshold, count);
		if(f1.size()==0)
		    break;
	}
	file.close();
	ofile.close();
	//cout << float( clock () - begin_time ) /  CLOCKS_PER_SEC<<" seconds";
    return 0;
}
