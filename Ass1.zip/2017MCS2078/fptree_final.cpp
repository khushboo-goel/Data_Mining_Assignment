#include<iostream>
#include<fstream>
#include <iterator>
#include<sstream>
#include<unordered_map>
#include<vector>
#include<algorithm>
#include<ctime>
using namespace std;

struct Node{
	unordered_map<int,Node *> child_map;
	int data,cnt;
	Node * parent_ptr;
	int parent_val;
	Node * ll_ptr;
	
};


int total_trans=0;
unordered_map<int, Node *> header_list; //Storing the header table for all unique items in the transaction
unordered_map <int,unsigned long int> fq_count; //Map to store frequency of 1-length frequent itemset
vector <int> unique_el; //identify unique elements for sorting

int sp_thres=1;      // TAKE INPUT FROM USER
struct Node root_node; //NULL root node of the FP tree
string input_file_name="";
string op_file="";

struct Cmp{
	unordered_map<int,int> m;
	Cmp(unordered_map<int,int> mp){ this->m=mp;}
	bool operator () (int a,int b){
		if (m[a]>m[b])
		return true;
	else
		return false;
	}
};
bool compare(int a, int b){               //for sorting the vector in order of frequency
	if (fq_count[a]>fq_count[b])
		return true;
	else
		return false;
}

/*Function to count frequency of the unique items in the trans DB*/
// void countFrequency(){
// 	ifstream myfile;
// 	myfile.open(input_file_name); //reading file
// 	int r;
// 	while(myfile){
// 		myfile>>r;
// 		if (fq_count.find(r)!=fq_count.end()){
// 			fq_count[r]++;
// 		}
// 		else{
// 			fq_count[r]=1;
// 			unique_el.push_back(r);
// 		}
// 	}
// 	sort(unique_el.begin(), unique_el.end(), compare);
// 	myfile.close();
// }

void countFrequency(){
	char c;
	string t=" ";
	//vector<string> v;
	int r;
	fstream f("retail.dat", fstream::in);
	while(f>>noskipws>>c){
		if (c==' '){
			//v.push_back(t);
			r=stoi(t);
			if (fq_count.find(r)!=fq_count.end()){
				fq_count[r]++;
			}
			else{
				fq_count[r]=1;
				unique_el.push_back(r);
			}
			t="";
		}
		else if (c=='\n'){
			if (t!=""){
				r=stoi(t);
				if (fq_count.find(r)!=fq_count.end()){
					fq_count[r]++;
				}
				else{
					fq_count[r]=1;
					unique_el.push_back(r);
				}
			}
			t="";
			total_trans++;
		}
		else{
			t+=c;
		}
	}
	sort(unique_el.begin(), unique_el.end(), compare);
}

void addinTree(Node * root,vector<int> v,int i){
    if(i==v.size()|| ((float)fq_count[v[i]]/total_trans)*100<sp_thres) return;
    if((root->child_map).find(v[i])==(root->child_map).end()){
        struct Node * new_node=new Node();
        new_node->data=v[i];
        new_node->cnt=1;
        new_node->parent_ptr=root;
        new_node->parent_val=root->data;
        Node* temp=header_list[v[i]];
        header_list[v[i]]=new_node;
        new_node->ll_ptr=temp;
        (root->child_map)[v[i]]=new_node;
        addinTree(new_node,v,i+1);
    }
    else{
        (root->child_map)[v[i]]->cnt++;
        addinTree((root->child_map)[v[i]],v,i+1);
    }
}

void makeTree(){
    ifstream f;
	f.open(input_file_name); //reading file
	int r;

    Node * root= &root_node;
    root_node.data=0;
    root_node.cnt=0;
    root_node.parent_ptr=NULL;
    root_node.parent_val=-1;
    root_node.ll_ptr=NULL;
	// for(string line; getline(myfile, line);){
	// 	//total_trans+=1;
	// 	istringstream iss(line);
	// 	vector<int> v;
	// 	for(string t; iss>>t;){                          // splitting the string into integers
 //            v.push_back(stoi(t));
	// 	}
	// 	sort(v.begin(),v.end(),compare);
	// 	addinTree(root,v,0);
	// }
    char c;
	string t=" ";
	vector<int> v;
	//fstream f("retail.dat", fstream::in);
	while(f>>noskipws>>c){
		if (c==' '){
			r=stoi(t);
			v.push_back(r);
			t="";
		}
		else if (c=='\n'){
			if (t!=""){
				r=stoi(t);
				v.push_back(r);
			}
			sort(v.begin(),v.end(),compare);
			addinTree(root,v,0);
			t="";
			v.clear();
		}
		else{
			t+=c;
		}
	}
	

}

void addinConditionalTree(Node * root,vector<int> v,int pattern_item_frequency,int i,unordered_map<int,int> count_items_patternbase,vector<int> current_unique_el,unordered_map<int,Node *> & current_header_list){
    if(i==v.size()|| ((float)count_items_patternbase[v[i]]/total_trans)*100<sp_thres) { 
    	//cout<<v[i]<<" "<<((float)count_items_patternbase[v[i]])<<endl;
    	return;
    }
    if((root->child_map).find(v[i])==(root->child_map).end()){
        struct Node * new_node=new Node();
        new_node->data=v[i];
        new_node->cnt=pattern_item_frequency;
        new_node->parent_ptr=root;
        new_node->parent_val=root->data;
	    unordered_map<int,Node *> * m =new unordered_map<int,Node *> ();
	    new_node->child_map=*m;
        Node* temp=current_header_list[v[i]];
        current_header_list[v[i]]=new_node;
        new_node->ll_ptr=temp;
        (root->child_map)[v[i]]=new_node;
        addinConditionalTree(new_node,v,pattern_item_frequency,i+1,count_items_patternbase,current_unique_el,current_header_list);
    }
    else{
        (root->child_map)[v[i]]->cnt+=pattern_item_frequency;
        addinConditionalTree((root->child_map)[v[i]],v,pattern_item_frequency,i+1,count_items_patternbase,current_unique_el,current_header_list);
    }
}

Node * makeConditionalTree(vector<vector<int>> patternbase,vector<int> pattern_item_frequency,unordered_map<int,int> count_items_patternbase,vector<int> current_unique_el,unordered_map<int,Node *> & current_header_list){
	Node * root= new Node ();
	root->data=0;
    root->cnt=0;
    root->parent_ptr=NULL;
    root->parent_val=-1;
    root->ll_ptr=NULL;
    unordered_map<int,Node *> * m =new unordered_map<int,Node *> ();
	root->child_map=*m;
    //cout<<"p_base"<<patternbase.size()<<endl;
    for(int i=0;i<patternbase.size();i++){
	
    if(patternbase[i].size()!=0){
	//cout<<"pattern number "<<i<<"  my size "<<patternbase[i].size()<<endl;
    	sort(patternbase[i].begin(),patternbase[i].end(),Cmp(count_items_patternbase));
	
    	addinConditionalTree(root,patternbase[i],pattern_item_frequency[i],0,count_items_patternbase,current_unique_el,current_header_list);
	}
    }
    return root;
}

void freetree(Node * root){
	if(root==NULL) return;
	if((root->child_map).size()==0){
		delete (root);
		return;
	}
	unordered_map<int,Node *> ::iterator it=(root->child_map).begin();
	for(;it!=(root->child_map).end();it++){
		freetree(it->second);
	}
	delete (root);
} 


void fpgrowth(unordered_map<int, Node *> header_table,vector<int> current_unique_el,vector<string> & frequent_patterns,string patterntillnow,int flag){
		
	for(int i=header_table.size()-1;i>=0;i--){
		
		Node * current= header_table[current_unique_el[i]];
		int currentpattern=current->data; ////
		string savepattern= patterntillnow;
		if(flag==1) {
			savepattern+=" ";
		}
		savepattern+=to_string(currentpattern);
		// cout<<"c_data "<<current->data<<"  "<<to_string(currentpattern)<<endl;
		// for(int i=0; i<savepattern.length(); i++){
		// 	cout<<savepattern[i]<<"";
		// }
		// cout<<endl;
		/*for(int i=0; i<patterntillnow.size(); i++){
			cout<<patterntillnow[i]<<" ";
		}
		cout<<endl;*/
		
		frequent_patterns.push_back(savepattern);
		int current_count=0;
		vector<vector<int>> patternbase;
		vector<int> pattern_item_frequency;
		unordered_map<int,int> count_items_patternbase;
		unordered_map<int,Node *> current_header_list;
		vector<int> current_unique_el;
		while(current!=NULL){
			//cout<<"hllo"<<endl;
			current_count+=current->cnt;
			Node * pathpointer=current->parent_ptr;
			vector<int> currentpath;
			while(pathpointer->parent_ptr!=NULL){
				int c_cnt=pathpointer->data;
				currentpath.push_back(c_cnt);
				pathpointer=pathpointer->parent_ptr;
				if(count_items_patternbase.find(c_cnt)!=count_items_patternbase.end()){
					count_items_patternbase[c_cnt]+=current->cnt;
				}
				else{
					count_items_patternbase[c_cnt]=current->cnt;
					current_unique_el.push_back(c_cnt);
				}
			}
			pattern_item_frequency.push_back(current->cnt);
			patternbase.push_back(currentpath);
			current=current->ll_ptr;
		}
		//cout<<"my patternbase size "<<patternbase.size()<<endl;
		sort(current_unique_el.begin(),current_unique_el.end(),Cmp(count_items_patternbase));
		Node * conditional_tree_root=makeConditionalTree(patternbase,pattern_item_frequency,count_items_patternbase,current_unique_el,current_header_list);
		
		if((conditional_tree_root->child_map).size()!=0){
			fpgrowth(current_header_list,current_unique_el,frequent_patterns,savepattern,1);
			freetree(conditional_tree_root);
		}
		else{
			freetree(conditional_tree_root);
		}
	}
}

int main(int argc,char ** argv){
	input_file_name=argv[1];
    sp_thres=stoi(argv[2]);
    op_file=argv[3];
    op_file+=".txt";
    //const clock_t begin_time = clock();
    countFrequency();
    //cout<<fq_count.size()<<endl;
    makeTree();
    vector<string> frequent_patterns;
    string pattern="";
    //cout<<header_list.size()<<" "<<total_trans<<endl;
    fpgrowth(header_list,unique_el,frequent_patterns,pattern,0);
    // /*for(int i=0; i<frequent_patterns.size(); i++){
    // 	cout<<frequent_patterns[i];
    // 	cout<<endl;
    // }*/

    // //WRITE TO FILE

    ofstream o_file(op_file);
    ostream_iterator<string> output_iterator(o_file, "\n");
    copy(frequent_patterns.begin(), frequent_patterns.end(), output_iterator);
    // /*map<int,Node *> ::iterator it=root_node.child_map.begin();
    // int count=0;
    // for(;it!=root_node.child_map.end();it++){
    // 	count+=(it->second)->cnt;
    // }
    // cout<<count<<endl;
    //cout<<root_node.child_map.size()<<endl;*/
	//cout << float( clock () - begin_time ) /  CLOCKS_PER_SEC<<"seconds";
	return 0;
}
