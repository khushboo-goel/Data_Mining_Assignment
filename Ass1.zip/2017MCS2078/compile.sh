g++ -O3 apriori_final.cpp -o ap
g++ -O3 -std=c++11 fptree_final.cpp -o fp
