import sklearn.cluster as cluster
import matplotlib.pyplot as plt
import numpy as np
import copy
import scipy.spatial.distance as d
import time

data = np.loadtxt("dataset.txt")
# dist= d.pdist(data,'euclidean')
# for i in dist:
# 	if (i<=0.3):
# 		print(i)

t=time.time()
'''
dbscan = cluster.DBSCAN(eps=0.25,min_samples=8,metric='euclidean', algorithm='brute')
dbscan.fit(data)
print(time.time()-t)
result=dbscan.labels_
# x=np.chararray(result.shape)
with open("db_lib.txt",'w') as f:
	for i in result:
		f.write(str(i)+'\n')
'''
color_list=['r','#98F5FF','b','g','c','y','k','m','#A93226','#34495E' , '#5499C7',  '#145A32', '#17202A', '#6C3483',  '#7D6608', '#838B8B', '#D35400']

'''x = []
for i in result:
	x.append(color_list[(i+1)%16])
'''

# # x[result==1] = 'r'
# # x[result==0] = 'g'
# # # print(x)


# # for i in range(0, len(result)):
# # 	print(result[i])
'''
y=[]
db= np.loadtxt("plot.txt");
for i in db:
	if (i==-2):
		y.append(color_list[0])
	else:
		y.append(color_list[(int(i)+1)])
'''
z=[]
db1= np.loadtxt("plot_1.txt");
for i in db1:
	if (i==-2):
		z.append(color_list[0])
	else:
		z.append(color_list[(int(i)+1)%16])

# plt.figure(1)
# plt.scatter(data[:,0],data[:,1], color=x)
# plt.figure(2)
# plt.scatter(data[:,0],data[:,1],color = y)
plt.figure(3)
plt.xlabel('X')
plt.ylabel('Y')
plt.title('DBSCAN clustering')
plt.scatter(data[:,0],data[:,1],color = z)
plt.show()