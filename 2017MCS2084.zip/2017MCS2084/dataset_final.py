from sklearn.datasets import make_moons, make_classification, make_circles, make_blobs
import matplotlib.pyplot as plt
import random, numpy as np
X, y = make_moons(n_samples=47000, noise=0.1)
q1, q2 = make_blobs(n_samples=17000, centers=[(-3, 10)], n_features=2, cluster_std=0.1)
r1, r2 = make_blobs(n_samples=17000, centers=[(-7.5, 10)], n_features=2, cluster_std=2)
s1, s2 = make_blobs(n_samples=17000, centers=[(-10.5, 10)], n_features=2, cluster_std=0.2)

f=np.concatenate((q1, r1), axis=0)
f=np.concatenate((f, s1), axis=0)
f=np.concatenate((f, X), axis=0)

x4=np.random.uniform(1.2*min(f[:, 0]), 1.2*max(f[:, 0]), 2000)
y4=np.random.uniform(min(f[:, 1])-2, 1.2*max(f[:, 1]), 2000)
z=np.column_stack((x4, y4))

f=np.concatenate((f, z), axis=0)

plt.scatter(q1[:, 0], q1[:, 1])
plt.scatter(r1[:, 0], r1[:, 1])
plt.scatter(s1[:, 0], s1[:, 1])
plt.scatter(X[:, 0], X[:, 1])
# 
plt.scatter(z[:, 0], z[:, 1])
#plt.scatter(f[:,0],f[:, 1])
plt.show()
np.savetxt("dataset.txt", f)
