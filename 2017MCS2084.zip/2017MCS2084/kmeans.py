import sys
from random import shuffle
import numpy as np
import math
import copy
# import matplotlib.pyplot as plt

input_file_name = sys.argv[2]
k = int(sys.argv[1])
output_file_name = "kmeans.txt"
n = 0
dim = 0

def read_file():
	global n,dim
	points_list = []
	with open(input_file_name,'r') as f:
		for line in f:
			n += 1
			line=line.rstrip()
			u = line.split(' ')
			point = []
			dim = len(u)
			for i in u:
				point.append(float(i))
			points_list.append(point)
		f.close()
		return points_list

def distance(point,k_means):
	np_point = np.array(point)
	min_dist = sys.maxsize
	min_cluster_id = -1
	for i,center in enumerate(k_means):
		dist = np.sum(np.square((np_point-np.array(center))))**0.5
		if dist < min_dist:
			min_dist = dist
			min_cluster_id = i
	return min_cluster_id

def diff(temp_mean,k_means):
	for i in range(len(temp_mean)):
		for j in range(len(k_means[i])):
			if(abs(temp_mean[i][j]-k_means[i][j])!=0):
				return True
	return False

def kmeans(points_list):
	k_means = []
	point_cluster_id = [-1]*n
	for i in range(k):
		k_means.append(points_list[i])
	
	f = 0
	temp_mean = k_means
	itr=0
	while(f!=1 or (diff(temp_mean,k_means) and itr<500)):
		itr+=1
		f = 1
		temp_mean = copy.copy(k_means)
		new_mean = [np.zeros(dim)] * k
		new_mean_count = [0] * k
		for i,point in enumerate(points_list):
			min_cluster_id = distance(point,k_means)
			point_cluster_id[i] = min_cluster_id
			new_mean[min_cluster_id] = (np.array(new_mean[min_cluster_id]) + np.array(point)).tolist()
			new_mean_count[min_cluster_id] += 1
		for i in range(len(new_mean)):
			new_mean[i] = (np.array(new_mean[i])/new_mean_count[i]).tolist()
		k_means = new_mean
	
	# #PLOT
	# color_list=['r','#98F5FF','b','g','c','y','k','m']
	# color =[]
	# for i in point_cluster_id:
	# 	color.append(color_list[i])
	# plt.scatter(np.array(points_list)[:,0],np.array(points_list)[:,1],color=color)
	# plt.xlabel('X')
	# plt.ylabel('Y')
	# plt.title('k-Means clustering')
	# plt.show()

	with open(output_file_name,'w') as f:
		for i in range(k):
			f.write('#'+str(i)+'\n')
			for j in range(len(point_cluster_id)):
				if(point_cluster_id[j] == i ):
					f.write(str(j)+'\n')
		f.close()

points_list = read_file()
shuffle(points_list)
kmeans(points_list)