g++ -O3 -std=c++11 kd_dbscan.cpp -o kdd
g++ -O3 -std=c++11 optics.cpp -o opt
