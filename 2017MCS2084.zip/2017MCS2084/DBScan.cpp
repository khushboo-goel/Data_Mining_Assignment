#include<iostream>
#include<ctime>
#include<vector>
#include<math.h>
#include<fstream>
#include<sstream>
#include<algorithm>
using namespace std;

string input_file;
int minpts;
float epsilon;

//representation of a point
//representing a point as a structure of vector with fixed dimensions as readed from file
vector<vector<float>> dataPoints;
vector<pair<int,int>> status_of_point;

bool compare(pair<int, int> a, pair<int, int> b){
	return a.second<b.second;
}

void readFile(){
	ifstream myfile;
	myfile.open(input_file); //reading file
	float r;
	for(string line; getline(myfile, line);){
		istringstream iss(line);
		vector<float> temp;
		for(string t; iss>>t;){                    
			r = stof(t);
			// cout<<r<<endl;
			temp.push_back(r);
		}
		dataPoints.push_back(temp);
		temp.clear();
	}
}

float calculate_distance(int x, int y){
	float distance=0;
	// cout<<dataPoints[x].size()<<endl;
	for(int i=0; i<dataPoints[x].size(); i++){
		distance+=pow((dataPoints[x][i]-dataPoints[y][i]),2);
	}
	
	distance = pow(distance, 0.5);
	// cout<<distance<<endl;
	// cout<<distance<<endl;
	return distance;
}

vector<int> find_eps_neighbour(int pt, float epsilon){
	vector<int> neighbour;
	float distance;
	for(int i=0; i<dataPoints.size(); i++){
		if (i!=pt){
			distance= calculate_distance(i, pt);
			if (distance<=epsilon){
				// cout<<distance<<endl;
				neighbour.push_back(i);
			}
		}
	}
	neighbour.push_back(pt);
	return neighbour;

}

bool expandCluster(int pt, int CI, int minpts, float epsilon){
	vector<int> seed_set = find_eps_neighbour(pt, epsilon);
	cout<<seed_set.size()<<endl;
	//cout<<seed_set.size()<<".....................";
	if (seed_set.size()<minpts){
		status_of_point[pt].second=-2; // -2 indicates noise, -1 indicates unclassified, rest indicates cluster_number
		//set point pt as noise(not core point but do not know if it is an outlier)
		return false;
	}
	else{
		for(int i=0; i<seed_set.size(); i++){
			status_of_point[seed_set[i]].second=CI;
		}
		seed_set.pop_back();
		while(!seed_set.empty()){
			int current_point = seed_set[0];
			vector<int> current_seed_set=find_eps_neighbour(current_point, epsilon);
			if(current_seed_set.size()>=minpts){
				for(int i=0; i<current_seed_set.size(); i++){
					int status = status_of_point[current_seed_set[i]].second;
					if (status==-1 || status==-2){
						if (status==-1){
							seed_set.push_back(current_seed_set[i]);
						}
						status_of_point[current_seed_set[i]].second=CI;
					}
				}
			}
			seed_set.erase(seed_set.begin());
		}
		return true;
	}
	return true;
}

void DBScan(int minpts, float epsilon){
	int cluster_id = 0;
	int d = dataPoints.size();
	for(int i=0; i<d; i++){
		status_of_point.push_back(make_pair(i,-1));
	}
	for(int i=0; i < d; i++){
		// cout<<i<<endl;
		int status = status_of_point[i].second;
		if (status==-1){
			if (expandCluster(i, cluster_id, minpts, epsilon)){
				//cout<<"Here"<<endl;
				cluster_id++;
			}

		}
	}
}

int main(int argc, char **argv){
	//assign input_file, minpts, epsilon;
	
	minpts=stoi(argv[1]);
	epsilon=stof(argv[2]);
	input_file = argv[3];
	const clock_t begin_time = clock();

	//write the code here
	readFile();
	// for(int i=0; i<dataPoints.size(); i++){
	// 	for(int j=0; j<dataPoints[i].size(); j++){
	// 		cout<<dataPoints[i][j]<<" ";
	// 	}
	// 	cout<<endl;
	// }
	DBScan(minpts, epsilon);
	// for(int i=0; i<status_of_point.size(); i++){
	// 	cout<<status_of_point[i]<<endl;
	// }
	string plot_file="plot.txt";
	fstream file;
	file.open(plot_file, fstream::out);
	for(int i=0; i<status_of_point.size(); i++){
		file<<status_of_point[i].second<<endl;
	}
	file.close();
	sort(status_of_point.begin(), status_of_point.end(), compare);
	// for(int i=0; i<status_of_point.size(); i++){
	// 	cout<<status_of_point[i].first<<" "<<status_of_point[i].second<<endl;
	// }
	int c=-3;
	string op_file="dbscan.txt";
	fstream ofile;
    ofile.open(op_file.c_str(), fstream::out);
    for(int i=0;i<status_of_point.size();i++)
    {
    	if (status_of_point[i].second>c && status_of_point[i].second==-2){
    		ofile<<"#outlier"<<endl;
    		c=status_of_point[i].second;
    	}
    	else if (status_of_point[i].second>c){
    		c=status_of_point[i].second;
    		ofile<<"#"<<c<<endl;
    	}
    	ofile<<status_of_point[i].first<<endl;
    }
    ofile.close();

	cout << "Execution Time"<<float( clock () - begin_time ) /  CLOCKS_PER_SEC<<"seconds"<<endl;
	return 0;
}