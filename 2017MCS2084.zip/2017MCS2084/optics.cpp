#include<iostream>
#include <fstream>
#include <sstream>
#include<vector>
#include<algorithm>
#include<map>
#include<cmath>
#include<cfloat>
#define undefined INFINITY
using namespace std;
int total_count=0;
class data_pt
{
    public:
        vector<float> val;
        int id;
        bool processed; // false true
        float reachability_distance, core_distance;
        data_pt(){}
        data_pt(vector<float> arr, int i)
        {
            val=arr;
            id=i;
            reachability_distance=undefined;
            core_distance=undefined;
            processed=false;
        }
};
vector<data_pt> points;
class compare
{
    public: bool operator()(const int &o1,const int &o2)const
    {
        return points[o1].reachability_distance<points[o2].reachability_distance;
    }
};
vector<data_pt> read_data(string fname)
{
    ifstream file;
    file.open(fname.c_str());
    string line, word;
    vector<float> v;
    vector<data_pt> points;
    while(getline(file, line))
	{
		istringstream iss(line);
        v.clear();
        /*while (getline(ss, word, ' '))
        {
		    v.push_back(stof(word));
	    }*/
        for(string t; iss>>t;){                    
            v.push_back(stof(t));
        }

	    data_pt obj(v, total_count);
		total_count++;
	    points.push_back(obj);
	}
	return points;
}
float dist(data_pt a, data_pt b)
{
    float x=0;
    for(int i=0;i<a.val.size();i++)
    {
        x += (a.val[i]-b.val[i])*(a.val[i]-b.val[i]);
    }
    return sqrt(x);
}
vector<int> find_neighbours(data_pt obj, float eps, vector<float> &distances)
{
    vector<int> neighbours;
    float d;
    for(int i=0;i<points.size();i++)
    {
        if(points[i].id==obj.id )
            continue;
        d=dist(obj, points[i]);
        if(d<=eps)
        {
        	neighbours.push_back(i);
            distances.push_back(d);
        }
    }
	vector<pair<int, int> > n;
	for(int i=0;i<neighbours.size();i++)
	{
		n.push_back(make_pair(distances[i], neighbours[i]));
	}
	sort(n.begin(), n.end());
	neighbours.clear();
	distances.clear();
	for(int i=0;i<n.size();i++)
	{
		neighbours.push_back(n[i].second);
		distances.push_back(n[i].first);
	}
    return neighbours;
}
void set_core_distance(data_pt &obj, float eps, int min_pts, vector<float> distances)
{
	if(distances.size()==0 || distances.size()<min_pts)
	{
		return;
	}
    sort(distances.begin(), distances.end());
    if(distances[min_pts-1]<=eps)
        obj.core_distance=distances[min_pts-1];
} 
void update(map<int, int, compare> &seed, vector<int> &neighbours, data_pt center)
{
    float cd=center.core_distance;
    for(int i=0;i<neighbours.size();i++)
    {
        data_pt & obj = points[neighbours[i]];
        if(!obj.processed)
        {
        	float rd=max(cd, dist(center, obj));
            if(obj.reachability_distance==undefined)
            {
                obj.reachability_distance=rd;
                seed[obj.id]=0;
            }
            else
            {
                if(rd<obj.reachability_distance)
                {
                    seed.erase(obj.id);
                    obj.reachability_distance = rd;
                    seed[obj.id]=0;
                }
            }
        }
    }
}
void expand(data_pt &obj, float eps, int min_pts, fstream &ofile, map<int, int, compare> & seed)
{
    vector<float> distances;
    vector<int> neighbours=find_neighbours(obj, eps, distances);
    obj.processed=true;
    obj.reachability_distance=undefined;
    set_core_distance(obj, eps, min_pts, distances);
    ofile<<obj.reachability_distance<<endl;
    
    if(obj.core_distance!=undefined)
    {
        update(seed, neighbours, obj);
        while(seed.size())
        {
        	data_pt &curr = points[seed.begin()->first];
            seed.erase(seed.begin());
            distances.clear();
            neighbours.clear();
            neighbours=find_neighbours(curr, eps, distances);
            curr.processed=true;
            set_core_distance(curr, eps, min_pts, distances);
            ofile<<curr.reachability_distance<<endl;
            if(curr.core_distance!=undefined)
                update(seed, neighbours, curr);
        }
    }
}
void optics(float eps, int min_pts, string op_file)
{
	fstream ofile;
    ofile.open(op_file.c_str(), fstream::out);
    map<int, int, compare> seed;
    for(int i=0;i<points.size();i++)
    {
        data_pt &obj = points[i];
        if(!obj.processed)
        {
        	expand(obj, eps, min_pts, ofile, seed);
        }
    }
    ofile.close();
}
int main(int argc, char** argv)
{
	int min_pts;
	stringstream ss(argv[1]);
	ss>>min_pts;
    float eps;
	stringstream ss1(argv[2]);
	ss1>>eps;
 	string fname=argv[3], op_file="optics.txt";
    points = read_data(fname);
    optics(eps, min_pts, op_file);
    return 0;
}
