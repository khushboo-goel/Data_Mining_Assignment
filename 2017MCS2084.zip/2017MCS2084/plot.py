import matplotlib.pyplot as plt
import numpy as np

rd=np.loadtxt("optics.txt")

x = np.arange(len(rd))
plt.bar(x, rd)
plt.xlabel('Cluster-order of the objects')
plt.ylabel('Reachability distance')
plt.title('Reachability plot')
plt.savefig("optics_plot.png")
plt.show()
