if [ "$1" = "-dbscan" ]
then
	./kdd $2 $3 $4
elif [ "$1" = "-optics" ] 
then
	./opt $2 $3 $4
	python plot.py
elif [ "$1" = '-kmeans' ]
then
	python kmeans.py $2 $3
else
	echo Invalid Option
fi
