from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt
import sys

y=int(sys.argv[1])
file_name=sys.argv[2]
X = np.loadtxt(file_name)
kmeans = KMeans(n_clusters=y).fit(X)
result = kmeans.labels_

color_list=['r','#98F5FF','b','g','c','y','k','m'] #change it for more colors
color =[]
for i in result:
	color.append(color_list[i])

plt.scatter(X[:,0],X[:,1],color=color)
plt.show()