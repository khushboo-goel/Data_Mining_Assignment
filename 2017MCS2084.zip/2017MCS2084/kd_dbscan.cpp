#include<iostream>
#include<ctime>
#include<vector>
#include<math.h>
#include<fstream>
#include<sstream>
#include<algorithm>
#include<bits/stdc++.h>
using namespace std;

string input_file;
int minpts;
float epsilon;

//representation of a point
//representing a point as a structure of vector with fixed dimensions as readed from file
vector<vector<float>> dataPoints;
vector<pair<int,int>> status_of_point;

struct node{
	int index;
	int pnt_ind;
	int dim;
	float median_value;  //float or double
	node *parent=NULL;
	node *left=NULL,*right = NULL;
};

struct Cmp{
	int m;
	Cmp(int d){ this->m=d;}
	bool operator () (int a,int b){
		if (dataPoints[a][m]<dataPoints[b][m])
		return true;
	else
		return false;
	}
};


void sort_index(int *index_list,int curr_dim, int n){
	sort(index_list,index_list+n,Cmp(curr_dim));
}

bool compare(pair<int, int> a, pair<int, int> b){
	return a.second<b.second;
}

void readFile(){
	ifstream myfile;
	myfile.open(input_file); //reading file
	float r;
	for(string line; getline(myfile, line);){
		istringstream iss(line);
		vector<float> temp;
		for(string t; iss>>t;){                    
			r = stof(t);
			temp.push_back(r);
		}
		dataPoints.push_back(temp);
		temp.clear();
	}
}


node * construct_tree(int *index_list,int n,int curr_dim,int total_dim,node * parent_ptr){
	if(n==0){
		return NULL;
	}

	if(n==1){
		node * new_node = (struct node*)malloc(sizeof(node));
		new_node -> index = index_list[0];
		new_node -> pnt_ind = index_list[0];
		new_node -> dim = curr_dim;
		new_node -> median_value = dataPoints[index_list[0]][curr_dim];
		new_node -> parent = parent_ptr;
		new_node -> left = NULL;
		new_node -> right = NULL;
		return new_node;

	}
	sort_index(index_list,curr_dim, n);
	int med_ind = -1;
	if(n%2 == 0){
		med_ind = n/2 - 1;
	}
	else{
		med_ind = n/2;
	}
	float med_val = dataPoints[index_list[med_ind]][curr_dim];
	node * new_node = (struct node *)malloc(sizeof(node));
	new_node -> index = index_list[med_ind];
	new_node -> dim = curr_dim;
	new_node -> median_value = med_val;
	new_node -> parent = parent_ptr;
	new_node -> left = construct_tree(index_list,med_ind,(curr_dim+1)%total_dim,total_dim,new_node);
	new_node -> right = construct_tree(index_list+med_ind+1,n-1-med_ind,(curr_dim+1)%total_dim,total_dim,new_node);

	return new_node;
}

float calculate_distance(vector<float> x, vector<float> y){
	float distance=0;
	for(int i=0; i<x.size(); i++){
		distance+=pow((x[i]-y[i]),2);
	}
	
	distance = pow(distance, 0.5);
	return distance;
}

void k_nearest_neighbour(float epsilon, node* root, vector <int> &neighbour, vector<float> curr_pnt){
	if (root==NULL){
		return;
	}
	else if (root->left==NULL && root->right==NULL){
		float dist=calculate_distance(dataPoints[root->index], curr_pnt);
		if (dist<=epsilon && dist>0){
			neighbour.push_back(root->index);
			return;
		}
	}
	else{
		int dim= root->dim;
		float med_val = root->median_value;
		if (curr_pnt[dim]==med_val){
			float dist=calculate_distance(dataPoints[root->index], curr_pnt);
			if (dist<=epsilon && dist>0){
				neighbour.push_back(root->index);
			}
			k_nearest_neighbour(epsilon, root->left, neighbour, curr_pnt);
			k_nearest_neighbour(epsilon, root->right, neighbour, curr_pnt);
			return;
		}
		else if (curr_pnt[dim]<med_val){
			k_nearest_neighbour(epsilon, root->left, neighbour, curr_pnt);
			if (abs(curr_pnt[dim]-med_val)<epsilon){
				float dist=calculate_distance(dataPoints[root->index], curr_pnt);
				if (dist<=epsilon && dist>0){
					neighbour.push_back(root->index);
				}
				k_nearest_neighbour(epsilon, root->right, neighbour, curr_pnt);
			}
			return;
		}
		else{
			k_nearest_neighbour(epsilon, root->right, neighbour, curr_pnt);
			if (abs(curr_pnt[dim]-med_val)<epsilon){
				float dist=calculate_distance(dataPoints[root->index], curr_pnt);
				if (dist<=epsilon && dist>0){
					neighbour.push_back(root->index);
				}
				k_nearest_neighbour(epsilon, root->left, neighbour, curr_pnt);
			}
			return;
		}
		return;
	}
}

bool expandCluster(int pt, int CI, int minpts, float epsilon, node *root){
	vector <int> seed_set;
	k_nearest_neighbour(epsilon, root, seed_set, dataPoints[pt]);
	seed_set.push_back(pt);

	if (seed_set.size()<minpts){
		status_of_point[pt].second=-2; // -2 indicates noise, -1 indicates unclassified, rest indicates cluster_number
		//set point pt as noise(not core point but do not know if it is an outlier)
		return false;
	}
	else{
		for(int i=0; i<seed_set.size(); i++){
			status_of_point[seed_set[i]].second=CI;
		}
		seed_set.pop_back();
		while(!seed_set.empty()){
			int current_point = seed_set[0];
			vector<int> current_seed_set;
			k_nearest_neighbour(epsilon, root, current_seed_set, dataPoints[current_point]);
			current_seed_set.push_back(current_point);
			if(current_seed_set.size()>=minpts){
				for(int i=0; i<current_seed_set.size(); i++){
					int status = status_of_point[current_seed_set[i]].second;
					if (status==-1 || status==-2){
						if (status==-1){
							seed_set.push_back(current_seed_set[i]);
						}
						status_of_point[current_seed_set[i]].second=CI;
					}
				}
			}
			seed_set.erase(seed_set.begin());
		}
		return true;
	}
	return true;
}

void DBScan(int minpts, float epsilon, node* root){
	int cluster_id = 0;
	int d = dataPoints.size();
	for(int i=0; i<d; i++){
		status_of_point.push_back(make_pair(i,-1));
	}
	for(int i=0; i < d; i++){
		int status = status_of_point[i].second;
		if (status==-1){
			if (expandCluster(i, cluster_id, minpts, epsilon, root)){
				cluster_id++;
			}

		}
	}
}

int main(int argc, char **argv){
	//assign input_file, minpts, epsilon;
	
	minpts=stoi(argv[1]);
	epsilon=stof(argv[2]);
	input_file = argv[3];
	// const clock_t begin_time = clock();

	//write the code here
	readFile();

	int index_list[dataPoints.size()];
	for(int i=0;i<dataPoints.size();i++){
		index_list[i] = i;
	}
	// const clock_t kd_time=clock();
	struct node* root = construct_tree(index_list,dataPoints.size(),0,dataPoints[0].size(),NULL);
	// cout<<float( clock () - kd_time ) /  CLOCKS_PER_SEC<<"seconds"<<endl;
	DBScan(minpts, epsilon, root);

	// string plot_file="plot_1.txt";
	// fstream file;
	// file.open(plot_file, fstream::out);
	// for(int i=0; i<status_of_point.size(); i++){
	// 	file<<status_of_point[i].second<<endl;
	// }
	// file.close();

	sort(status_of_point.begin(), status_of_point.end(), compare);
	int c=-3;
	string op_file="dbscan.txt";
	fstream ofile;
    ofile.open(op_file.c_str(), fstream::out);
    for(int i=0;i<status_of_point.size();i++)
    {
    	if (status_of_point[i].second>c && status_of_point[i].second==-2){
    		ofile<<"#outlier"<<endl;
    		c=status_of_point[i].second;
    	}
    	else if (status_of_point[i].second>c){
    		c=status_of_point[i].second;
    		ofile<<"#"<<c<<endl;
    	}
    	ofile<<status_of_point[i].first<<endl;
    }
    ofile.close();
	// cout << "Execution Time "<<float( clock () - begin_time ) /  CLOCKS_PER_SEC<<"seconds"<<endl;
	return 0;
}