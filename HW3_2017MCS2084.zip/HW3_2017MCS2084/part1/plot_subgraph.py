import matplotlib.pyplot as plt
support = [5, 10, 25, 50, 95]
gspan =[133.019, 62.5001, 24.7961, 10.3959, 1.49377]
fsg=[135.5, 70.2, 28.6, 9.9, 0.5]
gaston=[26.7242, 12.0061, 3.97979, 1.57181, 0.241688]

plt.plot(support, gspan)
plt.plot(support, fsg)
plt.plot(support, gaston)
plt.legend(['GSPAN', 'FSG', 'GASTON'], loc='upper right')
plt.xlabel("Support")
plt.ylabel("Time (seconds) ")
plt.title("Running times")
plt.savefig("Running_time.png")
plt.show()
